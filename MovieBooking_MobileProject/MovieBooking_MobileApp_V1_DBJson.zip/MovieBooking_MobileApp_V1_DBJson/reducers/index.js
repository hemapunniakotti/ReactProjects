import { combineReducers } from 'redux';

import latest from './latest_reducer';

const rootReducer = combineReducers({


    latest
}); 

export default rootReducer;